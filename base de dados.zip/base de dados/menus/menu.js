const menu2 = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *INFO DO BOT*
▢ ⌁ Prefix: ${prefixobot}     
▢ ⌁ Data: ${date}
▢ ⌁ Hora: ${hora()}
▢ ⌁ Bot: ${BotName}
╰────────────▢

╭─▢ *CONFIGURAÇÕES - BOT*
▢ ⌁ ${prefixobot}Nome-bot 
▢ ⌁ ${prefixobot}Nome-dono 
▢ ⌁ ${prefixobot}Numero-dono 
▢ ⌁ ${prefixobot}Numero-bot
▢ ⌁ ${prefixobot}Prefixo-bot 
▢ ⌁ ${prefixobot}Foto-menu 
▢ ⌁ ${prefixobot}Foto-bot 
╰────────────▢

╭─▢ *SUPORTE*
▢ ⌁ ${prefixobot}Bug  
▢ ⌁ ${prefixobot}Sugestão
▢ ⌁ ${prefixobot}Convite
╰────────────▢

╭─▢ *COMANDOS*
▢ ⌁ ${prefixobot}Menudono
▢ ⌁ ${prefixobot}menuconfig
▢ ⌁ ${prefixobot}Menufigu
▢ ⌁ ${prefixobot}Menulogos
▢ ⌁ ${prefixobot}Menuhentai
▢ ⌁ ${prefixobot}Menuanime
▢ ⌁ ${prefixobot}Menubrincadeiras 
╰────────────▢

╭─▢ *PESQUISANDO*
▢ ⌁ ${prefixobot}Chatgpt
▢ ⌁ ${prefixobot}Print 
▢ ⌁ ${prefixobot}Clima 
▢ ⌁ ${prefixobot}Traduzir
▢ ⌁ ${prefixobot}letras 
▢ ⌁ ${prefixobot}Ffstalk 
▢ ⌁ ${prefixobot}Google 
▢ ⌁ ${prefixobot}Gitstalk 
▢ ⌁ ${prefixobot}Gitclone 
▢ ⌁ ${prefixobot}Pinterest 
▢ ⌁ ${prefixobot}Pokemon 
▢ ⌁ ${prefixobot}Npmstalk 
▢ ⌁ ${prefixobot}Happymod
╰────────────▢

╭─▢ *DOWNLOADER*
▢ ⌁ ${prefixobot}Play ( Nome )
▢ ⌁ ${prefixobot}Down_v ( Link )
▢ ⌁ ${prefixobot}Down_a ( Link )
▢ ⌁ ${prefixobot}Mediafire ( Link )
▢ ⌁ ${prefixobot}Link ( imagem/Vídeo )
╰────────────▢

╭─▢ *STICKERS - FIGURINHAS*
▢ ⌁ ${prefixobot}Exif ( Dono de Stk ) 
▢ ⌁ ${prefixobot}S2 ( Texto do Img - Vid )
▢ ⌁ ${prefixobot}Sticker 
▢ ⌁ ${prefixobot}Fsticker 
▢ ⌁ ${prefixobot}Togif
▢ ⌁ ${prefixobot}Toimg 
▢ ⌁ ${prefixobot}Tomp3 
▢ ⌁ ${prefixobot}Sfundo 
▢ ⌁ ${prefixobot}Rename 
▢ ⌁ ${prefixobot}Emojimix
╰────────────▢

╭─▢ *BÁSICO*
▢ ⌁ ${prefixobot}Tabela 
▢ ⌁ ${prefixobot}Tabela2
▢ ⌁ ${prefixobot}Tabela3
▢ ⌁ ${prefixobot}Tabela4
▢ ⌁ ${prefixobot}Tabela5
▢ ⌁ ${prefixobot}Tabela6
▢ ⌁ ${prefixobot}Walink
▢ ⌁ ${prefixobot}Tagme 
▢ ⌁ ${prefixobot}Enquete 
╰────────────▢
`
}
exports.menu2 = menu2

const menubrincadeiras = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *PORCENTAGENS*
▢ ⌁ ${prefixobot}Gay 
▢ ⌁ ${prefixobot}Puta 
▢ ⌁ ${prefixobot}Feio 
▢ ⌁ ${prefixobot}Corno 
▢ ⌁ ${prefixobot}Vesgo 
▢ ⌁ ${prefixobot}Shipo 
▢ ⌁ ${prefixobot}Beijo 
▢ ⌁ ${prefixobot}Tapa 
▢ ⌁ ${prefixobot}Matar 
▢ ⌁ ${prefixobot}Casal 
▢ ⌁ ${prefixobot}Chute 
▢ ⌁ ${prefixobot}Bebado 
▢ ⌁ ${prefixobot}Chance 
▢ ⌁ ${prefixobot}Gostoso
▢ ⌁ ${prefixobot}Gostosa 
╰────────────▢
  
╭─▢ *RANKS* 
▢ ⌁ ${prefixobot}Rankcasal
▢ ⌁ ${prefixobot}Rankgay 
▢ ⌁ ${prefixobot}Rankgado 
▢ ⌁ ${prefixobot}Rankcorno 
▢ ⌁ ${prefixobot}Rankgostoso
▢ ⌁ ${prefixobot}Rankgostosa 
▢ ⌁ ${prefixobot}Rankotakus 
▢ ⌁ ${prefixobot}Rankpau
╰────────────▢

╭─▢ *JOGOS* 
▢ ⌁ ${prefixobot}Dinheiro
▢ ⌁ ${prefixobot}Minerar
▢ ⌁ ${prefixobot}Cassino 
▢ ⌁ ${prefixobot}Dado  
▢ ⌁ ${prefixobot}Batalha-z
▢ ⌁ ${prefixobot}Resetforca
▢ ⌁ ${prefixobot}Jogodavelha 
▢ ⌁ ${prefixobot}Jogodaforca
▢ ⌁ ${prefixobot}Regras-jogo
╰────────────▢
`
}
exports.menubrincadeiras = menubrincadeiras

const menudono = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *DONO*
▢ ⌁ ${prefixobot}Eval
▢ ⌁ ${prefixobot}Mek
▢ ⌁ ${prefixobot}Exec
▢ ⌁ ${prefixobot}Setbio 
▢ ⌁ ${prefixobot}Listagp 
▢ ⌁ ${prefixobot}Criargp 
▢ ⌁ ${prefixobot}Sairgp 
▢ ⌁ ${prefixobot}Block 
▢ ⌁ ${prefixobot}Clone 
▢ ⌁ ${prefixobot}Unblock 
▢ ⌁ ${prefixobot}Antipvon 
▢ ⌁ ${prefixobot}Antipvoff
▢ ⌁ ${prefixobot}Antiligar
▢ ⌁ ${prefixobot}Antipv
▢ ⌁ ${prefixobot}Bangp
▢ ⌁ ${prefixobot}Unbangp
▢ ⌁ ${prefixobot}Seradm
▢ ⌁ ${prefixobot}Sermembro
▢ ⌁ ${prefixobot}Tmgrupo
▢ ⌁ ${prefixobot}Limparpasta
▢ ⌁ ${prefixobot}Serpremium
▢ ⌁ ${prefixobot}Addpremium
▢ ⌁ ${prefixobot}Delpremium
▢ ⌁ ${prefixobot}Ganharxp
▢ ⌁ ${prefixobot}Ganharlevel
▢ ⌁ ${prefixobot}Reiniciar
▢ ⌁ ${prefixobot}Reviverqr
╰────────────▢
`
}
exports.menudono = menudono

const menuconfig = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *GRUPOS - ADMS*
▢ ⌁ ${prefixobot}Ban 
▢ ⌁ ${prefixobot}Kick 
▢ ⌁ ${prefixobot}Adm
▢ ⌁ ${prefixobot}Add 
▢ ⌁ ${prefixobot}Divug 
▢ ⌁ ${prefixobot}Grupo 
▢ ⌁ ${prefixobot}Regras
▢ ⌁ ${prefixobot}Reviver
▢ ⌁ ${prefixobot}Demote
▢ ⌁ ${prefixobot}Delete
▢ ⌁ ${prefixobot}Linkgp
▢ ⌁ ${prefixobot}Limpar 
▢ ⌁ ${prefixobot}Fotogp 
▢ ⌁ ${prefixobot}Descgp 
▢ ⌁ ${prefixobot}Autofigu
▢ ⌁ ${prefixobot}Leveling 
▢ ⌁ ${prefixobot}Novolink
▢ ⌁ ${prefixobot}Nomegp 
▢ ⌁ ${prefixobot}Hidetag 
▢ ⌁ ${prefixobot}Tagall
▢ ⌁ ${prefixobot}Mute 
▢ ⌁ ${prefixobot}Unmute 
▢ ⌁ ${prefixobot}Privadm
▢ ⌁ ${prefixobot}Desprivadm
▢ ⌁ ${prefixobot}Msgtemp
▢ ⌁ ${prefixobot}Listanegra
▢ ⌁ ${prefixobot}Delremover
▢ ⌁ ${prefixobot}Autoreação
▢ ⌁ ${prefixobot}Abrirgp 
▢ ⌁ ${prefixobot}Fechargp
╰────────────▢

╭─▢ *CONFIGURAÇÕES - GRUPOS*
▢ ⌁ ${prefixobot}Antiaudio
▢ ⌁ ${prefixobot}Anticontato
▢ ⌁ ${prefixobot}Anticontato2
▢ ⌁ ${prefixobot}Antifake
▢ ⌁ ${prefixobot}Antilink
▢ ⌁ ${prefixobot}Antidivu
▢ ⌁ ${prefixobot}Antilinkgp
▢ ⌁ ${prefixobot}Antisticker
▢ ⌁ ${prefixobot}Antiimg
▢ ⌁ ${prefixobot}Antivideo
▢ ⌁ ${prefixobot}Antiloc
▢ ⌁ ${prefixobot}Bemvindo
▢ ⌁ ${prefixobot}Bemvindo2
▢ ⌁ ${prefixobot}Anticatalogo
▢ ⌁ ${prefixobot}Modohentai
▢ ⌁ ${prefixobot}Limitecaracteres
▢ ⌁ ${prefixobot}Antidocumento
▢ ⌁ ${prefixobot}Modobrincadeira
╰────────────▢
`
}
exports.menuconfig = menuconfig

const menulogos = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *BANNER - LOGOS*
▢ ⌁ ${prefixobot}Gfx 
▢ ⌁ ${prefixobot}Gfx2 
▢ ⌁ ${prefixobot}Gfx3 
▢ ⌁ ${prefixobot}Gfx4 
▢ ⌁ ${prefixobot}Gfx5 
▢ ⌁ ${prefixobot}Gura2 
▢ ⌁ ${prefixobot}Joker 
▢ ⌁ ${prefixobot}Glitch 
▢ ⌁ ${prefixobot}Itachi 
▢ ⌁ ${prefixobot}Izuku 
▢ ⌁ ${prefixobot}Inosuke
▢ ⌁ ${prefixobot}Rezero 
▢ ⌁ ${prefixobot}Satoru 
▢ ⌁ ${prefixobot}Shoto 
▢ ⌁ ${prefixobot}Shoto2 
▢ ⌁ ${prefixobot}Mikey 
▢ ⌁ ${prefixobot}Kakashi 
▢ ⌁ ${prefixobot}Komi 
▢ ⌁ ${prefixobot}Batman 
▢ ⌁ ${prefixobot}NeonDevil
╰────────────▢
`
}
exports.menulogos = menulogos

const menuanime = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *ANIMES - IMG*
▢ ⌁ ${prefixobot}Naruto 
▢ ⌁ ${prefixobot}Komi2 
▢ ⌁ ${prefixobot}Kaguya 
▢ ⌁ ${prefixobot}Zero 
▢ ⌁ ${prefixobot}Tanjiro 
▢ ⌁ ${prefixobot}Neko 
▢ ⌁ ${prefixobot}Itsuki 
▢ ⌁ ${prefixobot}Chizuru
▢ ⌁ ${prefixobot}Hinata 
▢ ⌁ ${prefixobot}Sakura 
▢ ⌁ ${prefixobot}Zoro 
▢ ⌁ ${prefixobot}Asuna 
▢ ⌁ ${prefixobot}Akame 
▢ ⌁ ${prefixobot}Nezuko 
▢ ⌁ ${prefixobot}Lolis 
▢ ⌁ ${prefixobot}Waifu 
▢ ⌁ ${prefixobot}Shota
▢ ⌁ ${prefixobot}Megumin 
▢ ⌁ ${prefixobot}Nagatoro 
▢ ⌁ ${prefixobot}Sakurajima 
▢ ⌁ ${prefixobot}Metadinha 
▢ ⌁ ${prefixobot}Wallpaper4k 
╰────────────▢

╭─▢ *ANIMES - VIDEO*
▢ ⌁ ${prefixobot}Editanime 
▢ ⌁ ${prefixobot}Jotaroedit
▢ ⌁ ${prefixobot}Kagamiedit 
╰────────────▢
`
}
exports.menuanime = menuanime

const menuhentai = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *NSFW - IMG*
▢ ⌁ ${prefixobot}Ass 
▢ ⌁ ${prefixobot}Ahegao 
▢ ⌁ ${prefixobot}Bdsm 
▢ ⌁ ${prefixobot}Blowjob 
▢ ⌁ ${prefixobot}Cuckold
▢ ⌁ ${prefixobot}Cum 
▢ ⌁ ${prefixobot}Ero 
▢ ⌁ ${prefixobot}Femdom 
▢ ⌁ ${prefixobot}Foot 
▢ ⌁ ${prefixobot}Gangbang 
▢ ⌁ ${prefixobot}Glasses 
▢ ⌁ ${prefixobot}Hentai 
▢ ⌁ ${prefixobot}Jahy 
▢ ⌁ ${prefixobot}Manga 
▢ ⌁ ${prefixobot}Masturbation
▢ ⌁ ${prefixobot}Nsfwneko
▢ ⌁ ${prefixobot}Kasedaiki 
▢ ⌁ ${prefixobot}Orgy 
▢ ⌁ ${prefixobot}Panties 
▢ ⌁ ${prefixobot}Tentacles
▢ ⌁ ${prefixobot}Thighs 
▢ ⌁ ${prefixobot}Yuri 
▢ ⌁ ${prefixobot}Zettai 
╰────────────▢

╭─▢ *NSFW - VIDEO*
▢ ⌁ ${prefixobot}hentaivid 
╰────────────▢
`
}
exports.menuhentai = menuhentai

const menufigu = (prefixobot, BotName, nmrdono, nmrdonoo, hora, date, sender) => {
return `
╭─▢ *STICKERS - TEXTO*
▢ ⌁ ${prefixobot}Ttp
▢ ⌁ ${prefixobot}Ttp2 
▢ ⌁ ${prefixobot}Ttp3 
▢ ⌁ ${prefixobot}Ttp4 
▢ ⌁ ${prefixobot}Ttp5 
▢ ⌁ ${prefixobot}Ttp6 
▢ ⌁ ${prefixobot}Attp 
▢ ⌁ ${prefixobot}Attp2
▢ ⌁ ${prefixobot}Attp3
▢ ⌁ ${prefixobot}Attp4
▢ ⌁ ${prefixobot}Attp5
╰────────────▢

╭─▢ *STICKERS - PACK*
▢ ⌁ ${prefixobot}Animestick 
▢ ⌁ ${prefixobot}Gura 
▢ ⌁ ${prefixobot}Hentaistick 
▢ ⌁ ${prefixobot}Animegif2 
╰────────────▢

╭─▢ *STICKERS - EMOJI*
▢ ⌁ ${prefixobot}Semoji ( 🤓/Google )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Samsung )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Microsoft )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Whatsapp )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Twitter )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Facebook )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Openmoji )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Emojidex )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Joypixels )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Htc )
▢ ⌁ ${prefixobot}Semoji ( 🤓/Ig )
╰────────────▢

╭─▢ *STICKERS - FIGURINHAS*
▢ ⌁ ${prefixobot}Exif ( Dono de Stk ) 
▢ ⌁ ${prefixobot}S2 ( Texto do Img - Vid )
▢ ⌁ ${prefixobot}Sticker 
▢ ⌁ ${prefixobot}Fsticker 
▢ ⌁ ${prefixobot}Togif
▢ ⌁ ${prefixobot}Toimg 
▢ ⌁ ${prefixobot}Tomp3 
▢ ⌁ ${prefixobot}Sfundo 
▢ ⌁ ${prefixobot}Rename 
▢ ⌁ ${prefixobot}Emojimix
╰────────────▢
`
}
exports.menufigu = menufigu